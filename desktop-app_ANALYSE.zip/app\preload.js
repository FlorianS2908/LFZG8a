const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('lfzq8aDesktop', {
  getSetupState: () => ipcRenderer.invoke('setup:get-state'),
  saveSetup: (settings) => ipcRenderer.invoke('setup:save', settings),
  startWorkshop: () => ipcRenderer.invoke('setup:start-workshop'),
  openTeacherInfo: (url) => ipcRenderer.invoke('teacher:open', url),
  openParticipantReleases: () => ipcRenderer.invoke('teacher:open-releases'),
  openInEditor: (target) => ipcRenderer.invoke('editor:open', target),
  getCourseState: () => ipcRenderer.invoke('course:get-state'),
  getTaskPackages: () => ipcRenderer.invoke('task-packages:get'),
  getTaskReleases: () => ipcRenderer.invoke('task-releases:get'),
  saveTaskRelease: (taskId, release) => ipcRenderer.invoke('task-release:save', taskId, release),
  bulkUpdateTaskReleases: (filter, values) => ipcRenderer.invoke('task-release:bulk', filter, values),
  resetTaskReleases: () => ipcRenderer.invoke('task-release:reset'),
  onTaskReleasesChanged: (callback) => {
    const listener = (event, releases) => callback(releases);
    ipcRenderer.on('task-releases:changed', listener);
    return () => ipcRenderer.removeListener('task-releases:changed', listener);
  },
  getParticipantReleases: () => ipcRenderer.invoke('participant-releases:get'),
  saveParticipantReleases: (releases) => ipcRenderer.invoke('participant-releases:save', releases),
  onParticipantReleasesChanged: (callback) => {
    const listener = (event, releases) => callback(releases);
    ipcRenderer.on('participant-releases:changed', listener);
    return () => ipcRenderer.removeListener('participant-releases:changed', listener);
  },
  getClassroomInfo: () => ipcRenderer.invoke('classroom:get-info'),
  listParticipants: () => ipcRenderer.invoke('classroom:list-participants'),
  listHistory: () => ipcRenderer.invoke('history:list'),
  addHistory: (entry) => ipcRenderer.invoke('history:add', entry),
  resetHistory: () => ipcRenderer.invoke('history:reset'),
  createTestReport: () => ipcRenderer.invoke('test-report:create'),
  listTestReports: () => ipcRenderer.invoke('test-report:list'),
  openTestReportDir: () => ipcRenderer.invoke('test-report:open-dir'),
  moveViewToMonitor: (viewType, displayId) => ipcRenderer.invoke('display:move-view', viewType, displayId),
  highlightMonitor: (displayId, label) => ipcRenderer.invoke('display:highlight', displayId, label),
  openDataDir: () => ipcRenderer.invoke('app:open-data-dir'),
  getWorkspaceState: () => ipcRenderer.invoke('workspace:get-state'),
  saveWorkspaceProfile: (profile) => ipcRenderer.invoke('workspace:save-profile', profile),
  openLanding: () => ipcRenderer.invoke('workspace:open-landing'),
  openLfzq8a: () => ipcRenderer.invoke('workspace:open-lfzq8a'),
  openModule: (moduleId) => ipcRenderer.invoke('workspace:open-module', moduleId),
  openWizard: () => ipcRenderer.invoke('workspace:open-wizard'),
  auth: {
    getState: () => ipcRenderer.invoke('auth:get-state'),
    login: (credentials) => ipcRenderer.invoke('auth:login', credentials),
    logout: () => ipcRenderer.invoke('auth:logout'),
    changePassword: (input) => ipcRenderer.invoke('auth:change-password', input)
  },
  factory: {
    getState: () => ipcRenderer.invoke('factory:get-state'),
    duplicateContainer: (options) => ipcRenderer.invoke('factory:duplicate-container', options),
    importFiles: (input) => ipcRenderer.invoke('factory:import-files', input),
    updateMapping: (batchId, fileId, mapping) => ipcRenderer.invoke('factory:update-mapping', batchId, fileId, mapping),
    validateBatch: (batchId) => ipcRenderer.invoke('factory:validate-batch', batchId),
    createContainerFromBatch: (batchId, options) => ipcRenderer.invoke('factory:create-container-from-batch', batchId, options),
    publishContainer: (containerId, options) => ipcRenderer.invoke('factory:publish-container', containerId, options),
    disableContainer: (containerId) => ipcRenderer.invoke('factory:disable-container', containerId),
    archiveContainer: (containerId) => ipcRenderer.invoke('factory:archive-container', containerId)
  },
  dokuTool: {
    getQuizConfig: () => ipcRenderer.invoke('dokutool:quiz-config'),
    getQuizQuestions: (query) => ipcRenderer.invoke('dokutool:quiz-questions', query),
    saveQuizProfile: (profile) => ipcRenderer.invoke('dokutool:quiz-profile-save', profile),
    analyze: (input) => ipcRenderer.invoke('dokutool:analyze', input),
    listReports: () => ipcRenderer.invoke('dokutool:reports-list'),
    getReport: (reportId) => ipcRenderer.invoke('dokutool:report-get', reportId)
  }
});

window.addEventListener('DOMContentLoaded', () => {
  document.addEventListener('click', (event) => {
    const link = event.target.closest && event.target.closest('a.teacher-open');
    if (!link || !window.lfzq8aDesktop) {
      return;
    }

    event.preventDefault();
    window.lfzq8aDesktop.openTeacherInfo(link.href);
  });

  document.addEventListener('click', async (event) => {
    const button = event.target.closest && event.target.closest('[data-open-editor]');
    if (!button || !window.lfzq8aDesktop) {
      return;
    }

    event.preventDefault();
    const target = new URL(button.dataset.openEditor, window.location.href).href;
    try {
      await window.lfzq8aDesktop.openInEditor(target);
    } catch (error) {
      window.alert(`VS Code konnte nicht gestartet werden: ${error.message}`);
    }
  });
});
