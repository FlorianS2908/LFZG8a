const desktop = window.lfzq8aDesktop;

function $(selector) {
  return document.querySelector(selector);
}

function setStatus(message) {
  $('[data-login-status]').textContent = message || '';
}

async function init() {
  if (!desktop?.auth) {
    document.body.innerHTML = '<main class="login-shell"><section class="login-panel"><h1>Electron API nicht verfuegbar</h1></section></main>';
    return;
  }

  const session = await desktop.auth.getState();
  if (session.authenticated) {
    await desktop.openLanding();
    return;
  }

  $('[data-login-form]').addEventListener('submit', async (event) => {
    event.preventDefault();
    setStatus('Login wird geprueft ...');
    const result = await desktop.auth.login({
      email: $('[data-login-email]').value,
      password: $('[data-login-password]').value
    });
    if (!result.authenticated) {
      setStatus(result.error || 'Login fehlgeschlagen.');
    }
  });
}

init().catch((error) => {
  setStatus(error.message);
});
