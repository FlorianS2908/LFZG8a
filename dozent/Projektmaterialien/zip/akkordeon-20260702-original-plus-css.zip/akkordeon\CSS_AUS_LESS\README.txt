Diese CSS-Datei liegt separat zur Less-Struktur.
Die Originaldateien wurden nicht entfernt oder veraendert.
Quelle fuer diese CSS-Ausgabe ist die im Originalprojekt vorhandene kompilierte css/style.css, die aus der Less-Struktur stammt.